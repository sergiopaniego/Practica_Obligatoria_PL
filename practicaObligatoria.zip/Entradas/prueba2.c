int formula (int p1, int p2){
	int auxiliar;

	intercambio( p1 * 10, p2);
	auxiliar = auxiliar + -3 + p2 % 045 * 0-3 / 0+67;
	auxiliar = auxiliar  - (+98 - p1 * 0x+ABD % 0xFC4D);
	auxiliar = -3.98 + p2 % 045.27 * 0-3.11 / 0+67.34;
	auxiliar = auxiliar - (+98.5 - p1 * 0x+ABD.EE % 0xFC4D.F4);
	return auxiliar * 0x-FF;
}

void Main (int args){
	int entero1, entero2;

	printf('Esto es el programa \'principal\'...');
	real1 = formula(entero1, entero2);
}
